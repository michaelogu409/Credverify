const { ethers } = require('ethers');
const crypto = require('crypto');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

// ── Provider and Signer Setup ───────────────────────────────
const getProvider = () => {
  return new ethers.JsonRpcProvider(process.env.SEPOLIA_RPC_URL);
};

const getSigner = () => {
  const provider = getProvider();
  return new ethers.Wallet(process.env.PRIVATE_KEY, provider);
};

// ── ABI Definitions ─────────────────────────────────────────
const CREDENTIAL_REGISTRY_ABI = [
  'function issueCredential(string credentialId, string sha256Hash, string ipfsCID, address studentWallet) external',
  'function verifyCredential(string sha256Hash) external view returns (bool exists, bool isRevoked, string credentialId, address studentWallet, uint256 timestamp)',
  'function revokeCredential(string credentialId) external',
  'event CredentialIssued(string credentialId, string sha256Hash, string ipfsCID, address studentWallet, uint256 timestamp)',
];

const ACCESS_CONTROL_ABI = [
  'function grantAccess(string credentialId, address verifierWallet, string[] fieldsAllowed, uint256 expiryTimestamp) external',
  'function revokeAccess(string credentialId, address verifierWallet) external',
  'function checkAccess(string credentialId, address verifierWallet) external view returns (bool hasAccess, string[] fieldsAllowed, uint256 expiryDate)',
];

const PROGRESS_TRACKER_ABI = [
  'function recordProgress(address studentWallet, string moduleCode, string grade, uint256 completionDate) external',
  'function getProgressHistory(address studentWallet) external view returns (tuple(string moduleCode, string grade, uint256 completionDate, uint256 timestamp)[])',
  'function checkAccreditation(string programmeId) external view returns (bool compliant)',
];

// ── Contract Instances ───────────────────────────────────────
const getCredentialRegistry = () => {
  const signer = getSigner();
  return new ethers.Contract(
    process.env.CREDENTIAL_REGISTRY_ADDRESS,
    CREDENTIAL_REGISTRY_ABI,
    signer
  );
};

const getAccessControl = () => {
  const signer = getSigner();
  return new ethers.Contract(
    process.env.ACCESS_CONTROL_ADDRESS,
    ACCESS_CONTROL_ABI,
    signer
  );
};

const getProgressTracker = () => {
  const signer = getSigner();
  return new ethers.Contract(
    process.env.PROGRESS_TRACKER_ADDRESS,
    PROGRESS_TRACKER_ABI,
    signer
  );
};

// ── SHA-256 Hash Generation ──────────────────────────────────
const generateSHA256Hash = (fileBuffer) => {
  return crypto.createHash('sha256').update(fileBuffer).digest('hex');
};

// ── IPFS Upload via Pinata ───────────────────────────────────
const uploadToIPFS = async (fileBuffer, fileName) => {
  const formData = new FormData();
  formData.append('file', fileBuffer, { filename: fileName });

  const metadata = JSON.stringify({ name: fileName });
  formData.append('pinataMetadata', metadata);

  const options = JSON.stringify({ cidVersion: 0 });
  formData.append('pinataOptions', options);

  const response = await axios.post(
    'https://api.pinata.cloud/pinning/pinFileToIPFS',
    formData,
    {
      maxBodyLength: 'Infinity',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${formData._boundary}`,
        pinata_api_key: process.env.PINATA_API_KEY,
        pinata_secret_api_key: process.env.PINATA_SECRET_API_KEY,
      },
    }
  );

  const cid = response.data.IpfsHash;
  const ipfsUrl = `https://gateway.pinata.cloud/ipfs/${cid}`;
  return { cid, ipfsUrl };
};

// ── Issue Credential on Blockchain ───────────────────────────
const issueCredentialOnChain = async (credentialId, sha256Hash, ipfsCID, studentWallet) => {
  const contract = getCredentialRegistry();
  const tx = await contract.issueCredential(credentialId, sha256Hash, ipfsCID, studentWallet);
  const receipt = await tx.wait();
  return {
    txHash: receipt.hash,
    blockNumber: receipt.blockNumber,
  };
};

// ── Verify Credential on Blockchain ─────────────────────────
const verifyCredentialOnChain = async (sha256Hash) => {
  const provider = getProvider();
  const contract = new ethers.Contract(
    process.env.CREDENTIAL_REGISTRY_ADDRESS,
    CREDENTIAL_REGISTRY_ABI,
    provider // read-only, no signer needed
  );
  const result = await contract.verifyCredential(sha256Hash);
  return {
    exists: result.exists,
    isRevoked: result.isRevoked,
    credentialId: result.credentialId,
    studentWallet: result.studentWallet,
    timestamp: result.timestamp.toString(),
  };
};

// ── Grant Access on Blockchain ───────────────────────────────
const grantAccessOnChain = async (credentialId, verifierWallet, fieldsAllowed, expiryDate) => {
  const contract = getAccessControl();
  const expiryTimestamp = Math.floor(new Date(expiryDate).getTime() / 1000);
  const tx = await contract.grantAccess(credentialId, verifierWallet, fieldsAllowed, expiryTimestamp);
  const receipt = await tx.wait();
  return { txHash: receipt.hash };
};

// ── Revoke Access on Blockchain ──────────────────────────────
const revokeAccessOnChain = async (credentialId, verifierWallet) => {
  const contract = getAccessControl();
  const tx = await contract.revokeAccess(credentialId, verifierWallet);
  const receipt = await tx.wait();
  return { txHash: receipt.hash };
};

// ── Record Progress on Blockchain ───────────────────────────
const recordProgressOnChain = async (studentWallet, moduleCode, grade, completionDate) => {
  const contract = getProgressTracker();
  const timestamp = Math.floor(new Date(completionDate).getTime() / 1000);
  const tx = await contract.recordProgress(studentWallet, moduleCode, grade, timestamp);
  const receipt = await tx.wait();
  return { txHash: receipt.hash };
};

module.exports = {
  generateSHA256Hash,
  uploadToIPFS,
  issueCredentialOnChain,
  verifyCredentialOnChain,
  grantAccessOnChain,
  revokeAccessOnChain,
  recordProgressOnChain,
};