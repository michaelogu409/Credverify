const { ethers } = require('ethers');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Generate a random nonce for the user to sign
const generateNonce = () => {
  return Math.floor(Math.random() * 1000000).toString();
};

// Get or create user by wallet address and return their nonce
const getNonce = async (walletAddress) => {
  const address = walletAddress.toLowerCase();
  let user = await User.findOne({ walletAddress: address });

  if (!user) {
    return null; // User must be registered first
  }

  // Refresh nonce on every login attempt
  user.nonce = generateNonce();
  await user.save();

  return user.nonce;
};

// Verify the MetaMask signature and return a JWT if valid
const verifySignature = async (walletAddress, signature) => {
  const address = walletAddress.toLowerCase();
  const user = await User.findOne({ walletAddress: address });

  if (!user) {
    throw new Error('User not found. Please register first.');
  }

  const message = `Sign this message to authenticate with the Credential Verification System.\n\nNonce: ${user.nonce}`;

  // Recover the signer address from the signature
  const recoveredAddress = ethers.verifyMessage(message, signature);

  if (recoveredAddress.toLowerCase() !== address) {
    throw new Error('Signature verification failed. Invalid signature.');
  }

  // Refresh nonce after successful login to prevent replay attacks
  user.nonce = generateNonce();
  await user.save();

  // Generate JWT
  const token = jwt.sign(
    {
      walletAddress: user.walletAddress,
      role: user.role,
      userId: user._id,
    },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  );

  return {
    token,
    user: {
      walletAddress: user.walletAddress,
      role: user.role,
      name: user.name,
      email: user.email,
    },
  };
};

// Register a new user
const registerUser = async (walletAddress, role, name, email, extra = {}) => {
  const address = walletAddress.toLowerCase();

  const existing = await User.findOne({ walletAddress: address });
  if (existing) {
    throw new Error('Wallet address already registered.');
  }

  const user = await User.create({
    walletAddress: address,
    role,
    name,
    email,
    ...extra,
  });

  return user;
};

// Verify JWT middleware
const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired token.' });
  }
};

// Role-based access middleware
const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access denied. Required role: ${roles.join(' or ')}.`,
      });
    }
    next();
  };
};

module.exports = {
  getNonce,
  verifySignature,
  registerUser,
  verifyToken,
  requireRole,
};