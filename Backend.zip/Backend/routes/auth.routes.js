const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { verifyToken } = require('../services/auth.service');

// Register a new user
router.post('/register', authController.register);

// Get nonce for wallet signature
router.get('/nonce/:walletAddress', authController.getNonce);

// Verify MetaMask signature and login
router.post('/login', authController.login);

// Get current user profile (protected)
router.get('/profile', verifyToken, authController.getProfile);

module.exports = router;