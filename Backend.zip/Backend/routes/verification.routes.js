const express = require('express');
const router = express.Router();
const multer = require('multer');
const verificationController = require('../controllers/verification.controller');

// Multer for in-memory file handling
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'), false);
    }
  },
});

// Public verification endpoint — no authentication required
router.post(
  '/verify',
  upload.single('credentialFile'),
  verificationController.verifyCredential
);

module.exports = router;