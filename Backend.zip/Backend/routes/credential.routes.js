const express = require('express');
const router = express.Router();
const multer = require('multer');
const credentialController = require('../controllers/credential.controller');
const { verifyToken, requireRole } = require('../services/auth.service');

// Multer setup for in-memory file handling
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'), false);
    }
  },
});

// Issue a new credential (Administrator only)
router.post(
  '/issue',
  verifyToken,
  requireRole('administrator'),
  upload.single('credentialFile'),
  credentialController.issueCredential
);

// Get all credentials for a student (Student only)
router.get(
  '/my-credentials',
  verifyToken,
  requireRole('student'),
  credentialController.getMyCredentials
);

// Get all credentials issued by an institution (Administrator only)
router.get(
  '/issued',
  verifyToken,
  requireRole('administrator'),
  credentialController.getIssuedCredentials
);

// Grant selective access to a verifier (Student only)
router.post(
  '/grant-access',
  verifyToken,
  requireRole('student'),
  credentialController.grantAccess
);

// Revoke access from a verifier (Student only)
router.post(
  '/revoke-access',
  verifyToken,
  requireRole('student'),
  credentialController.revokeAccess
);

// Record academic progress (Administrator only)
router.post(
  '/record-progress',
  verifyToken,
  requireRole('administrator'),
  credentialController.recordProgress
);

module.exports = router;