const blockchainService = require('../services/blockchain.service');
const Credential = require('../models/Credential');

// POST /api/verification/verify
const verifyCredential = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Credential PDF file is required for verification.' });
    }

    // Step 1: Compute SHA-256 hash of submitted document
    const submittedHash = blockchainService.generateSHA256Hash(req.file.buffer);

    // Step 2: Query blockchain
    const onChainResult = await blockchainService.verifyCredentialOnChain(submittedHash);

    if (!onChainResult.exists) {
      return res.json({
        result: 'TAMPERED',
        message: 'This credential does not match any record on the blockchain. It may have been altered or is fraudulent.',
        submittedHash,
      });
    }

    if (onChainResult.isRevoked) {
      return res.json({
        result: 'REVOKED',
        message: 'This credential exists on the blockchain but has been revoked by the issuing institution.',
        submittedHash,
        credentialId: onChainResult.credentialId,
      });
    }

    // Step 3: Fetch credential metadata from MongoDB
    const credential = await Credential.findOne({ sha256Hash: submittedHash });

    res.json({
      result: 'AUTHENTIC',
      message: 'This credential is authentic. It matches the record stored on the Ethereum blockchain.',
      submittedHash,
      onChainData: {
        credentialId: onChainResult.credentialId,
        studentWallet: onChainResult.studentWallet,
        timestamp: new Date(Number(onChainResult.timestamp) * 1000).toISOString(),
      },
      metadata: credential
        ? {
            degreeTitle: credential.degreeTitle,
            institutionName: credential.institutionName,
            classification: credential.classification,
            issueDate: credential.issueDate,
            ipfsCID: credential.ipfsCID,
            ipfsUrl: credential.ipfsUrl,
            txHash: credential.txHash,
            sepoliaExplorerUrl: `https://sepolia.etherscan.io/tx/${credential.txHash}`,
          }
        : null,
    });
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({ error: error.message });
  }
};

module.exports = { verifyCredential };