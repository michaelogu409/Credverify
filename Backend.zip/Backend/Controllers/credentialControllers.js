const { v4: uuidv4 } = require('uuid');
const blockchainService = require('../services/blockchain.service');
const Credential = require('../models/Credential');
const User = require('../models/User');

// POST /api/credentials/issue
const issueCredential = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Credential PDF file is required.' });
    }

    const { studentWallet, degreeTitle, classification, issueDate } = req.body;

    if (!studentWallet || !degreeTitle || !issueDate) {
      return res.status(400).json({ error: 'studentWallet, degreeTitle, and issueDate are required.' });
    }

    // Step 1: Generate SHA-256 hash
    const sha256Hash = blockchainService.generateSHA256Hash(req.file.buffer);

    // Step 2: Check if credential already exists
    const existing = await Credential.findOne({ sha256Hash });
    if (existing) {
      return res.status(409).json({ error: 'This credential has already been issued.' });
    }

    // Step 3: Upload to IPFS
    const { cid, ipfsUrl } = await blockchainService.uploadToIPFS(
      req.file.buffer,
      req.file.originalname
    );

    // Step 4: Issue on Ethereum blockchain
    const credentialId = uuidv4();
    const institutionUser = await User.findOne({ walletAddress: req.user.walletAddress });

    const { txHash, blockNumber } = await blockchainService.issueCredentialOnChain(
      credentialId,
      sha256Hash,
      cid,
      studentWallet
    );

    // Step 5: Save to MongoDB
    const credential = await Credential.create({
      credentialId,
      studentWallet: studentWallet.toLowerCase(),
      institutionWallet: req.user.walletAddress,
      institutionName: institutionUser?.institutionName || 'Unknown Institution',
      degreeTitle,
      classification,
      issueDate: new Date(issueDate),
      sha256Hash,
      ipfsCID: cid,
      ipfsUrl,
      txHash,
      blockNumber,
      status: 'issued',
    });

    res.status(201).json({
      message: 'Credential issued successfully on the blockchain.',
      credential: {
        credentialId: credential.credentialId,
        sha256Hash: credential.sha256Hash,
        ipfsCID: credential.ipfsCID,
        ipfsUrl: credential.ipfsUrl,
        txHash: credential.txHash,
        blockNumber: credential.blockNumber,
        sepoliaExplorerUrl: `https://sepolia.etherscan.io/tx/${txHash}`,
      },
    });
  } catch (error) {
    console.error('Issue credential error:', error);
    res.status(500).json({ error: error.message });
  }
};

// GET /api/credentials/my-credentials
const getMyCredentials = async (req, res) => {
  try {
    const credentials = await Credential.find({
      studentWallet: req.user.walletAddress,
    }).sort({ createdAt: -1 });

    res.json({ credentials });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// GET /api/credentials/issued
const getIssuedCredentials = async (req, res) => {
  try {
    const credentials = await Credential.find({
      institutionWallet: req.user.walletAddress,
    }).sort({ createdAt: -1 });

    res.json({ credentials });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// POST /api/credentials/grant-access
const grantAccess = async (req, res) => {
  try {
    const { credentialId, verifierWallet, fieldsAllowed, expiryDate } = req.body;

    if (!credentialId || !verifierWallet || !fieldsAllowed || !expiryDate) {
      return res.status(400).json({ error: 'credentialId, verifierWallet, fieldsAllowed, and expiryDate are required.' });
    }

    const credential = await Credential.findOne({
      credentialId,
      studentWallet: req.user.walletAddress,
    });

    if (!credential) {
      return res.status(404).json({ error: 'Credential not found or does not belong to you.' });
    }

    // Issue on blockchain
    const { txHash } = await blockchainService.grantAccessOnChain(
      credentialId,
      verifierWallet,
      fieldsAllowed,
      expiryDate
    );

    // Update MongoDB record
    credential.sharingTokens.push({
      verifierWallet: verifierWallet.toLowerCase(),
      fieldsAllowed,
      expiryDate: new Date(expiryDate),
      revoked: false,
    });

    await credential.save();

    res.json({
      message: 'Access granted successfully on the blockchain.',
      txHash,
      sepoliaExplorerUrl: `https://sepolia.etherscan.io/tx/${txHash}`,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// POST /api/credentials/revoke-access
const revokeAccess = async (req, res) => {
  try {
    const { credentialId, verifierWallet } = req.body;

    const credential = await Credential.findOne({
      credentialId,
      studentWallet: req.user.walletAddress,
    });

    if (!credential) {
      return res.status(404).json({ error: 'Credential not found or does not belong to you.' });
    }

    const { txHash } = await blockchainService.revokeAccessOnChain(credentialId, verifierWallet);

    // Update MongoDB
    const token = credential.sharingTokens.find(
      (t) => t.verifierWallet === verifierWallet.toLowerCase() && !t.revoked
    );
    if (token) {
      token.revoked = true;
    }

    await credential.save();

    res.json({
      message: 'Access revoked successfully on the blockchain.',
      txHash,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// POST /api/credentials/record-progress
const recordProgress = async (req, res) => {
  try {
    const { studentWallet, moduleCode, grade, completionDate } = req.body;

    if (!studentWallet || !moduleCode || !grade || !completionDate) {
      return res.status(400).json({ error: 'studentWallet, moduleCode, grade, and completionDate are required.' });
    }

    const { txHash } = await blockchainService.recordProgressOnChain(
      studentWallet,
      moduleCode,
      grade,
      completionDate
    );

    res.json({
      message: 'Academic progress recorded on the blockchain.',
      txHash,
      sepoliaExplorerUrl: `https://sepolia.etherscan.io/tx/${txHash}`,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  issueCredential,
  getMyCredentials,
  getIssuedCredentials,
  grantAccess,
  revokeAccess,
  recordProgress,
};