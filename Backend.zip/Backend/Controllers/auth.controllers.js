const authService = require('../services/auth.service');
const User = require('../models/User');

// GET /api/auth/nonce/:walletAddress
const getNonce = async (req, res) => {
  try {
    const { walletAddress } = req.params;
    const nonce = await authService.getNonce(walletAddress);

    if (!nonce) {
      return res.status(404).json({ error: 'Wallet not registered. Please register first.' });
    }

    res.json({
      nonce,
      message: `Sign this message to authenticate with the Credential Verification System.\n\nNonce: ${nonce}`,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// POST /api/auth/register
const register = async (req, res) => {
  try {
    const { walletAddress, role, name, email, institutionName, studentId, organization } = req.body;

    if (!walletAddress || !role || !name) {
      return res.status(400).json({ error: 'walletAddress, role, and name are required.' });
    }

    const validRoles = ['administrator', 'student', 'verifier'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ error: 'Invalid role. Must be administrator, student, or verifier.' });
    }

    const extra = {};
    if (institutionName) extra.institutionName = institutionName;
    if (studentId) extra.studentId = studentId;
    if (organization) extra.organization = organization;

    const user = await authService.registerUser(walletAddress, role, name, email, extra);

    res.status(201).json({
      message: 'User registered successfully.',
      user: {
        walletAddress: user.walletAddress,
        role: user.role,
        name: user.name,
      },
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// POST /api/auth/login
const login = async (req, res) => {
  try {
    const { walletAddress, signature } = req.body;

    if (!walletAddress || !signature) {
      return res.status(400).json({ error: 'walletAddress and signature are required.' });
    }

    const result = await authService.verifySignature(walletAddress, signature);

    res.json({
      message: 'Login successful.',
      token: result.token,
      user: result.user,
    });
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
};

// GET /api/auth/profile
const getProfile = async (req, res) => {
  try {
    const user = await User.findOne({ walletAddress: req.user.walletAddress }).select('-nonce');

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { getNonce, register, login, getProfile };